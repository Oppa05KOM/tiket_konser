<?php

class Limit extends CI_Controller {
    public function index () 
        {
            $this->load->view('limit');
        }
    

}

?>
